
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.DisplayName;

import java.util.ArrayList;
import java.util.Arrays;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
//All test cases for three card logic
class TestThreeCardLogic {
	@Test
	void testEvalHand() {

		ArrayList<Card> hand = new ArrayList<>(Arrays.asList(
				new Card('H', 10),
				new Card('S', 10),
				new Card('D', 5)
		));

		int score = ThreeCardLogic.evalHand(hand);

		assertEquals(5, score, "The hand should be a pair");
	}
	@Test
	void testEvalHand2() {

		ArrayList<Card> hand = new ArrayList<>(Arrays.asList(
				new Card('H', 5),
				new Card('S', 4),
				new Card('D', 5)
		));

		int score = ThreeCardLogic.evalHand(hand);

		assertEquals(5, score, "The hand should be a pair");
	}
	@Test
	void testCompareHands() {
		ArrayList<Card> hand1 = new ArrayList<>(Arrays.asList(
				new Card('H', 5),
				new Card('H', 6),
				new Card('H', 7)
		));

		ArrayList<Card> hand2 = new ArrayList<>(Arrays.asList(
				new Card('S', 10),
				new Card('H', 10),
				new Card('D', 5)
		));

		// Compare hands
		int result = ThreeCardLogic.compareHands(hand1, hand2);

		// Assert that Player 1 wins because a straight flush beats a pair
		assertEquals(1, result, "Player 1 should win with a straight flush");
	}
	@Test
	void testCompareHands2() {
		ArrayList<Card> hand1 = new ArrayList<>(Arrays.asList(
				new Card('S', 3),
				new Card('S', 4),
				new Card('S', 2)
		));

		ArrayList<Card> hand2 = new ArrayList<>(Arrays.asList(
				new Card('S', 10),
				new Card('H', 10),
				new Card('D', 5)
		));
		assertEquals(1, ThreeCardLogic.compareHands(hand1, hand2));
	}
	@Test
	void testCompareHands3() {
		ArrayList<Card> hand1 = new ArrayList<>(Arrays.asList(
				new Card('C', 5),
				new Card('S', 4),
				new Card('S', 3)
		));

		ArrayList<Card> hand2 = new ArrayList<>(Arrays.asList(
				new Card('S', 14),
				new Card('S', 13),
				new Card('S', 12)
		));
		assertEquals(2, ThreeCardLogic.compareHands(hand1, hand2));
	}
	@Test
	void testCompareHands4() {
		//dealer not higher than queen
		ArrayList<Card> hand1 = new ArrayList<>(Arrays.asList(
				new Card('C', 5),
				new Card('S', 8),
				new Card('S', 3)
		));

		ArrayList<Card> hand2 = new ArrayList<>(Arrays.asList(
				new Card('S', 14),
				new Card('S', 13),
				new Card('S', 12)
		));
		assertEquals(0, ThreeCardLogic.compareHands(hand1, hand2));
	}
	@Test
	void testEvalHandThreeOfAKind() {
		ArrayList<Card> hand = new ArrayList<>(Arrays.asList(
				new Card('H', 7),
				new Card('S', 7),
				new Card('D', 7)
		));
		int score = ThreeCardLogic.evalHand(hand);
		assertEquals(2, score);
	}
	@Test
	void testEvalHandStraight() {
		ArrayList<Card> hand = new ArrayList<>(Arrays.asList(
				new Card('H', 4),
				new Card('S', 5),
				new Card('D', 6)
		));
		int score = ThreeCardLogic.evalHand(hand);
		assertEquals(3, score);
	}
	@Test
	void testEvalHandFlush() {
		ArrayList<Card> hand = new ArrayList<>(Arrays.asList(
				new Card('C', 2),
				new Card('C', 5),
				new Card('C', 10)
		));
		int score = ThreeCardLogic.evalHand(hand);
		assertEquals(4, score);
	}
	@Test
	void testEvalHandHighCard() {
		ArrayList<Card> hand = new ArrayList<>(Arrays.asList(
				new Card('H', 2),
				new Card('S', 7),
				new Card('D', 9)
		));
		int score = ThreeCardLogic.evalHand(hand);
		assertEquals(0, score);
	}
	@Test
	void testCompareHandsTieOnHighCard() {
		ArrayList<Card> hand1 = new ArrayList<>(Arrays.asList(
				new Card('S', 14),
				new Card('C', 7),
				new Card('H', 4)
		));
		ArrayList<Card> hand2 = new ArrayList<>(Arrays.asList(
				new Card('D', 14),
				new Card('S', 7),
				new Card('C', 4)
		));
		assertEquals(0, ThreeCardLogic.compareHands(hand1, hand2));
	}
	@Test
	void testCompareHandsLowerHighCard() {
		ArrayList<Card> hand1 = new ArrayList<>(Arrays.asList(
				new Card('H', 3),
				new Card('S', 5),
				new Card('C', 9)
		));
		ArrayList<Card> hand2 = new ArrayList<>(Arrays.asList(
				new Card('D', 10),
				new Card('H', 7),
				new Card('S', 2)
		));
		assertEquals(0, ThreeCardLogic.compareHands(hand1, hand2));
	}
	@Test
	void testCompareHandsBothFlushDifferentRanks() {
		ArrayList<Card> hand1 = new ArrayList<>(Arrays.asList(
				new Card('S', 4),
				new Card('S', 8),
				new Card('S', 12)
		));
		ArrayList<Card> hand2 = new ArrayList<>(Arrays.asList(
				new Card('D', 3),
				new Card('D', 9),
				new Card('D', 11)
		));
		assertEquals(1, ThreeCardLogic.compareHands(hand1, hand2));
	}
	@Test
	void testCompareHandsLowerHighCard2() {
		ArrayList<Card> hand1 = new ArrayList<>(Arrays.asList(
				new Card('H', 3),
				new Card('S', 2),
				new Card('C', 13)
		));
		ArrayList<Card> hand2 = new ArrayList<>(Arrays.asList(
				new Card('D', 10),
				new Card('H', 14),
				new Card('S', 2)
		));
		assertEquals(2, ThreeCardLogic.compareHands(hand1, hand2));
	}
	@Test
	void testCompareHandsNoQueenForDealer(){
		ArrayList<Card> hand1 = new ArrayList<>(Arrays.asList(
				new Card('C', 3),
				new Card('H', 4),
				new Card('S', 7)
		));
		ArrayList<Card> hand2 = new ArrayList<>(Arrays.asList(
				new Card('C', 2),
				new Card('H', 9),
				new Card('S', 8)
		));
		assertEquals(0, ThreeCardLogic.compareHands(hand1, hand2));
	}
	@Test
	void testCompareHandsBothFlushDifferentRanks2() {
		ArrayList<Card> hand1 = new ArrayList<>(Arrays.asList(
				new Card('S', 8),
				new Card('S', 6),
				new Card('S', 13)
		));
		ArrayList<Card> hand2 = new ArrayList<>(Arrays.asList(
				new Card('D', 3),
				new Card('D', 2),
				new Card('D', 12)
		));
		assertEquals(1, ThreeCardLogic.compareHands(hand1, hand2));
	}
	@Test
	void testEvalHandAceHighCard() {
		ArrayList<Card> hand = new ArrayList<>(Arrays.asList(
				new Card('D', 14),
				new Card('H', 7),
				new Card('S', 10)
		));
		assertEquals(0, ThreeCardLogic.evalHand(hand));
	}
	@Test
	void testCompareHandsTwoStraights() {
		ArrayList<Card> hand1 = new ArrayList<>(Arrays.asList(
				new Card('S', 5),
				new Card('H', 6),
				new Card('D', 7)
		));
		ArrayList<Card> hand2 = new ArrayList<>(Arrays.asList(
				new Card('C', 4),
				new Card('S', 5),
				new Card('H', 6)
		));
		assertEquals(1, ThreeCardLogic.compareHands(hand1, hand2));
	}
	@Test
	void testEvalHandKingHighCard() {
		ArrayList<Card> hand = new ArrayList<>(Arrays.asList(
				new Card('C', 13),
				new Card('H', 5),
				new Card('D', 3)
		));
		assertEquals(0, ThreeCardLogic.evalHand(hand));
	}
	@Test
	void testCompareHandsBothPairs() {
		ArrayList<Card> hand1 = new ArrayList<>(Arrays.asList(
				new Card('C', 8),
				new Card('H', 8),
				new Card('S', 3)
		));
		ArrayList<Card> hand2 = new ArrayList<>(Arrays.asList(
				new Card('D', 7),
				new Card('H', 7),
				new Card('C', 10)
		));
		assertEquals(2, ThreeCardLogic.compareHands(hand1, hand2));
	}

}
//All test cases for deck and dealer
class TestDeckAndDealer {
	@Test
	void testDeckInitialization() {
		Deck deck = new Deck();
		assertEquals(52, deck.size());
	}
	@Test
	void testDeckInitializationTwice(){
		Deck deck = new Deck();
		deck = new Deck();
		assertEquals(52, deck.size());
	}
	@Test
	void testDeckSizeAfterDealingHand() {
		Deck deck = new Deck();
		deck.remove(0);
		assertEquals(51, deck.size());
	}

	@Test
	void testDeckShuffle() {
		Deck deck1 = new Deck();
		Deck deck2 = new Deck();
		assertNotEquals(deck1, deck2);
	}

	@Test
	void testDeckNewDeckResetsSize() {
		Deck deck = new Deck();
		deck.remove(0);
		deck.newDeck();
		assertEquals(52, deck.size());
	}

	@Test
	void testDealerHandSizeAfterDeal() {
		Dealer dealer = new Dealer();
		ArrayList<Card> hand = dealer.dealHand();
		assertEquals(3, hand.size());
	}

	@Test
	void testDealerDeckSizeAfterDeal() {
		Dealer dealer = new Dealer();
		dealer.dealHand();
		assertEquals(49, dealer.theDeck.size());
	}

	@Test
	void testDealerDeckReshuffleWhenLow() {
		Dealer dealer = new Dealer();
		for (int i = 0; i < 7; i++) {
			dealer.dealHand();
		}
		assertEquals(49, dealer.theDeck.size());
	}
	@Test
	void testDealerUniqueHandsAfterMultipleDeals() {
		Dealer dealer = new Dealer();
		ArrayList<Card> hand1 = dealer.dealHand();
		ArrayList<Card> hand2 = dealer.dealHand();
		assertNotEquals(hand1, hand2);
	}
	@Test
	void testDealerDeckSizeAfterMultipleDeals() {
		Dealer dealer = new Dealer();
		for (int i = 0; i < 5; i++) {
			dealer.dealHand();
		}
		assertEquals(37, dealer.theDeck.size());
	}
}
