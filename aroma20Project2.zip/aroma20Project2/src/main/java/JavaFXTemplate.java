import javafx.animation.FadeTransition;
import javafx.animation.PauseTransition;
import javafx.animation.RotateTransition;
import javafx.animation.SequentialTransition;
import javafx.application.Application;

import javafx.geometry.Pos;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
/*
Adam Roman, 652253543, aroma20
Project 2 - 3 Card Poker game
Professor Mark Hallenbeck
11/10/2024
*/



public class JavaFXTemplate extends Application {
	//Initialize all players
	public Player playerOne;
	public Player playerTwo;
	public Dealer theDealer;

	//create screens
	private BorderPane welcomeScreen;
	private BorderPane gameplayScreen;
	//create labels for later use
	Label p1HandLabel;
	Label p2HandLabel;
	Label p1BetsLabel;
	Label p2BetsLabel;
	Label dealerHandLabel;
	Label resultLabel;
	Label resultLabel2;
	Label p1WinningsLabel;
	Label p2WinningsLabel;
	Label anteBetLabel1;
	Label playBetLabel1;
	Label pairPlusBetLabel1;
	Label anteBetLabel2;
	Label playBetLabel2;
	Label pairPlusBetLabel2;
	Label ppWon1 = new Label();
	Label ppWon2 = new Label();
	Label infoLabel = new Label();
	//initialize some booleans for later use
	boolean player1won = false;
	boolean player2won = false;
	boolean dealerWon = false;
	//Creates char variables for later use
	char p1PorF = 'x';
	char p2PorF = 'x';
	//determines input from user and updates the bet once button pressed
	private void placeAnteBet(int i, int player){
		if (player == 1) {
			playerOne.anteBet = i;
		} else if (player == 2) {
			playerTwo.anteBet = i;
		}
			System.out.println("Ante bet placed by Player" + player + ": " + i);
	}
	//same as ante, except for pair plus bet, takes input from field after button press
	private void placePairPlusBet(int i, int player){
		if (player == 1) {
			playerOne.pairPlusBet = i;
		} else if (player == 2) {
			playerTwo.pairPlusBet = i;
		}

		System.out.println("Pair bet placed by Player" + player + ": " + i);
	}
	//gives each player a hand and shows the players cards while keeping the dealer hidden
	//until either folded or played
	private void dealCards(){
		playerOne.hand = theDealer.dealHand();

        playerTwo.hand = theDealer.dealHand();

		theDealer.dealersHand = theDealer.dealHand();

        System.out.println("Player 1 hand: " + playerOne.hand);
		System.out.println("Player 2 hand: " + playerTwo.hand);

		String p1HandString = formatHand(playerOne.hand);
		String p2HandString = formatHand(playerTwo.hand);

		p1HandLabel.setText("Player 1 hand: " + p1HandString);
		p2HandLabel.setText("Player 2 hand: " + p2HandString);

		dealerHandLabel.setText("Dealer hand: ?? ?? ??");

		int playerOneScore = ThreeCardLogic.evalHand(playerOne.hand);
		int playerTwoScore = ThreeCardLogic.evalHand(playerTwo.hand);

		System.out.println("Player 1 score: " + playerOneScore);
		System.out.println("Player 2 score: " + playerTwoScore);
		//determines if win or lose
		int winner1 = ThreeCardLogic.compareHands(theDealer.dealersHand, playerOne.hand);
		int winner2 = ThreeCardLogic.compareHands(theDealer.dealersHand, playerTwo.hand);
		String resultMessage = "Error";
		String resultMessage2 = "Error";

		if (winner1 == 1) {
			player1won = true;
			resultMessage = "Player 1 wins!";
			//playerOne.money += bet;
		} else if (winner1 == 2) {
			dealerWon = true;
			resultMessage = "Dealer wins!";
		} else{
			resultMessage = "No one wins!";
		}
		if (winner2 == 1) {
			player2won = true;
			resultMessage2 = "Player 2 wins!";
		} else if (winner2 == 2) {
			dealerWon = true;
			resultMessage2 = "Dealer wins!";
		} else{
			resultMessage2 = "No one wins!";
		}

		resultLabel.setText(resultMessage);
		resultLabel2.setText(resultMessage2);
		System.out.println(resultMessage);
		System.out.println(resultMessage2);
	}
	//formats the cards to a more readable style
	private String formatHand(ArrayList<Card> hand){
		StringBuilder sb = new StringBuilder();
		for (Card card : hand) {
			String value = String.valueOf(card.value);
			if (card.value > 10) {
				if (card.value == 11) {
					value = "J";
				} else if (card.value == 12) {
					value = "Q";
				} else if (card.value == 13) {
					value = "K";
				} else if (card.value == 14) {
					value = "A";
				}
			}
			sb.append("[").append(value).append(" of ").append(card.suit).append("]").append(" ");
		}
		return sb.toString();
	}
	//once button pressed show the welcome screen and show play or exit button
	private void showWelcomeScreen(Stage primaryStage) {
		welcomeScreen = new BorderPane();
		welcomeScreen.setStyle("-fx-background-color: #354535");
		Label welcomeLabel = new Label("Welcome to Three Card Poker!");
		welcomeLabel.setFont(Font.font("Times New Roman", 50));
		welcomeLabel.setTextFill(Color.BLACK);
		Button playButton = new Button("Play");
		Button exitButton = new Button("Exit");

		playButton.setOnAction(e -> showGameplayScreen(primaryStage));
		exitButton.setOnAction(e -> primaryStage.close());

		VBox vbox = new VBox(20, welcomeLabel, playButton, exitButton);
		vbox.setAlignment(Pos.CENTER);
		welcomeScreen.setCenter(vbox);

		Scene welcomeScene = new Scene(welcomeScreen, 700, 700);
		primaryStage.setScene(welcomeScene);
		primaryStage.show();
	}
	public String result1 = " ";
	public String result2 = " ";
	//shows the gameplay screen, allows players to make bets as well as proceed through the game
	private void showGameplayScreen(Stage primaryStage){

		gameplayScreen = new BorderPane();
		gameplayScreen.setStyle("-fx-background-color: #F0FFF9");
		infoLabel.setText("");

		p1HandLabel = new Label("Player 1 hand: ");
		p2HandLabel = new Label("Player 2 hand: ");
		dealerHandLabel = new Label("Dealer hand: ");
		HBox cardsBox = new HBox(20, p1HandLabel, p2HandLabel, dealerHandLabel);
		cardsBox.setAlignment(Pos.CENTER);
		Label p1Label = new Label("Player 1: ");
		Label p2Label = new Label("Player 2: ");
		HBox playersBox = new HBox(300, p1Label, p2Label);
		playersBox.setAlignment(Pos.CENTER);
		anteBetLabel1 = new Label("Ante bet: ");
		playBetLabel1 = new Label("Play bet: ");
		pairPlusBetLabel1 = new Label("Pair Plus bet: ");
		anteBetLabel2 = new Label("Ante bet: ");
		playBetLabel2 = new Label("Play bet: ");
		pairPlusBetLabel2 = new Label("Pair Plus bet: ");

		Label anteFieldLabel = new Label("Ante bet (5-25):");
		TextField anteBetField = new TextField();
		//Label playBetField = new Label("Play bet: ");
		Label pairPlusFieldLabel = new Label("Pair Plus bet (5-25):");
		TextField pairPlusBetField = new TextField();

		Label Space = new Label("                                                   ");
		HBox inputs = new HBox(5, anteFieldLabel, anteBetField, pairPlusFieldLabel, pairPlusBetField);
		HBox betBox = new HBox(5, anteBetLabel1, playBetLabel1, pairPlusBetLabel1);
		betBox.getChildren().addAll(Space, anteBetLabel2, playBetLabel2, pairPlusBetLabel2);
		inputs.setAlignment(Pos.CENTER);
		betBox.setAlignment(Pos.CENTER);
		resultLabel = new Label("Result player 1: " + result1);
		resultLabel2 = new Label("Result player 2: " + result2);
		VBox resultBox = new VBox(5, infoLabel, resultLabel, resultLabel2);
		resultBox.setAlignment(Pos.TOP_CENTER);
		p1WinningsLabel = new Label("Player 1 winnings: " + playerOne.totalWinnings);
		p2WinningsLabel = new Label("Player 2 winnings: " + playerTwo.totalWinnings);
		p1BetsLabel = new Label("Player 1 bets: 0");
		p2BetsLabel = new Label("Player 2 bets: 0");

		VBox winningsBox = new VBox(10, p1WinningsLabel, p2WinningsLabel);
		winningsBox.setAlignment(Pos.CENTER);
		Button p1Bets = new Button("Player 1 bets " );
		Button p2Bets = new Button("Player 2 bets " );
		winningsBox.getChildren().addAll(p1Bets, p2Bets);
		Button dealButton = new Button("Deal cards");
		//Setups for button presses to have each button set bets for each player
		p1Bets.setOnAction(e -> {
			playerOne.anteBet = Integer.parseInt(anteBetField.getText());
			playerOne.pairPlusBet = Integer.parseInt(pairPlusBetField.getText());
			if (playerOne.anteBet >= 5 && playerOne.anteBet <= 25 && playerOne.pairPlusBet >= 5 && playerOne.pairPlusBet <= 25) {
				placeAnteBet(playerOne.anteBet, 1);
				placePairPlusBet(playerOne.pairPlusBet, 1);
				anteBetLabel1.setText("Ante bet: " + String.valueOf(playerOne.anteBet));
				playBetLabel1.setText("Play bet: " + String.valueOf(playerOne.anteBet));
				pairPlusBetLabel1.setText("Pair bet: " + String.valueOf(playerOne.pairPlusBet));

				p1BetsLabel.setText("Player 1 bets: " + (playerOne.anteBet + playerOne.playBet + playerOne.pairPlusBet));
			}
		});
		p2Bets.setOnAction(e -> {
			if (Integer.parseInt(anteBetField.getText()) >= 5 && Integer.parseInt(anteBetField.getText()) <= 25 && Integer.parseInt(pairPlusBetField.getText()) >= 5 && Integer.parseInt(pairPlusBetField.getText()) <= 25) {
				placeAnteBet(Integer.parseInt(anteBetField.getText()), 2);
				placePairPlusBet(Integer.parseInt(pairPlusBetField.getText()), 2);
				anteBetLabel2.setText("Ante bet: " + String.valueOf(playerTwo.anteBet));
				playBetLabel2.setText("Play bet: " + String.valueOf(playerTwo.anteBet));
				pairPlusBetLabel2.setText("Pair bet: " + String.valueOf(playerTwo.pairPlusBet));
				p2BetsLabel.setText("Player 2 bets: " + (playerTwo.anteBet + playerTwo.playBet + playerTwo.pairPlusBet));
			}
		});
		//setup for play or fold per player
		Button p1Play = new Button("Player 1 play");
		Button p2Play = new Button("Player 2 play");
		Button p1Fold = new Button("Player 1 fold");
		Button p2Fold = new Button("Player 2 fold");

		p1Play.setVisible(false);
		p2Play.setVisible(false);
		p1Fold.setVisible(false);
		p2Fold.setVisible(false);
		playBetLabel1.setVisible(false);
		playBetLabel2.setVisible(false);
		HBox buttonsBox = new HBox(10);
		buttonsBox.setAlignment(Pos.BOTTOM_CENTER);
		buttonsBox.getChildren().addAll(p1Play, p1Fold, p2Play, p2Fold);
		//once pressed will deal and lock in all bets, if bets aren't ready will not proceed
		dealButton.setOnAction(e -> {
			int p1Ante = playerOne.anteBet;
			int p2Ante = playerTwo.anteBet;
			int p1Pair = playerOne.pairPlusBet;
			int p2Pair = playerTwo.pairPlusBet;
			//determines if each bet is correct value range
			if (((p1Ante >= 5 && p1Ante <= 25) && (p1Pair >= 5 && p1Pair <= 25)) && ((p2Ante >= 5 && p2Ante <= 25) && (p2Pair >= 5 && p2Pair <= 25))){
				dealCards();
				anteBetLabel1.setText("Ante bet: " + String.valueOf(playerOne.anteBet));
				playBetLabel1.setText("Play bet: " + String.valueOf(playerOne.anteBet));
				pairPlusBetLabel1.setText("Pair bet: " + String.valueOf(playerOne.pairPlusBet));
				anteBetLabel2.setText("Ante bet: " + String.valueOf(playerTwo.anteBet));
				playBetLabel2.setText("Play bet: " + String.valueOf(playerTwo.anteBet));
				pairPlusBetLabel2.setText("Pair bet: " + String.valueOf(playerTwo.pairPlusBet));
				//shows all visible buttons and hides if necessary
				p1Play.setVisible(true);
				p1Fold.setVisible(true);
				dealButton.setVisible(false);
				p1Bets.setVisible(false);
				p2Bets.setVisible(false);
				anteBetField.setVisible(false);
				pairPlusBetField.setVisible(false);
				resultLabel.setVisible(false);
				resultLabel2.setVisible(false);
				anteFieldLabel.setVisible(false);
				pairPlusFieldLabel.setVisible(false);
			}
		});
		int p1Bet = (playerOne.anteBet + playerOne.anteBet + playerOne.pairPlusBet);
		int p2Bet = (playerTwo.anteBet + playerTwo.anteBet + playerTwo.pairPlusBet);
		//Setup for play and fold buttons
		p1Play.setOnAction(e -> {
			p1PorF = 'P';
			p1BetsLabel.setText("Player 1 bets: " + (playerOne.anteBet + playerOne.anteBet + playerOne.pairPlusBet));
			p1Play.setVisible(false);
			p1Fold.setVisible(false);
			p2Play.setVisible(true);
			p2Fold.setVisible(true);
			playBetLabel1.setVisible(true);

		});
		Button Continue = new Button("Continue");
		Continue.setVisible(false);
		p2Play.setOnAction(e -> {
			p2PorF = 'P';
			p2BetsLabel.setText("Player 2 bets: " + (playerTwo.anteBet + playerTwo.anteBet + playerTwo.pairPlusBet));
			p2Play.setVisible(false);
			p2Fold.setVisible(false);
			String dealerHandString = formatHand(theDealer.dealersHand);
			dealerHandLabel.setText("Dealer hand: " + dealerHandString);
			Continue.setVisible(true);

			playBetLabel2.setVisible(true);
			resultLabel.setVisible(true);
			resultLabel2.setVisible(true);
			//Determines how much won and calculates for player
			if (p1PorF == 'P'){
				int ppw1 = ThreeCardLogic.evalPPWinnings(playerOne.hand, playerOne.pairPlusBet);
				int wol = ThreeCardLogic.compareHands(theDealer.dealersHand, playerOne.hand);
				if (wol == 2){
					playerOne.totalWinnings -= (playerOne.anteBet + playerOne.pairPlusBet);
				} else if (wol == 1){
					playerOne.totalWinnings += (playerOne.anteBet + playerOne.anteBet);
				}
				playerOne.totalWinnings += ppw1;
				if (ppw1 > 0){
					resultLabel.setText(resultLabel.getText() + "\nPlayer 1 Won Pair Plus: " + ppw1);
				} else {
					resultLabel.setText(resultLabel.getText() + "\nPlayer 1 lost Pair Plus");
				}
			} else{
				playerOne.totalWinnings -= (playerTwo.anteBet + playerOne.pairPlusBet);
			}
			if (p2PorF == 'P') {
				int ppw2 = ThreeCardLogic.evalPPWinnings(playerTwo.hand, playerTwo.pairPlusBet);
				int wol = ThreeCardLogic.compareHands(theDealer.dealersHand, playerTwo.hand);
				if (wol == 2) {
					playerTwo.totalWinnings -= (playerTwo.anteBet + playerTwo.pairPlusBet);
				} else if (wol == 1) {
					playerTwo.totalWinnings += (playerTwo.anteBet + playerTwo.anteBet);
				}
				playerTwo.totalWinnings += ppw2;
				if (ppw2 > 0) {
					resultLabel2.setText(resultLabel2.getText() + "\nPlayer 2 Won Pair Plus: " + ppw2);
				} else {
					resultLabel2.setText(resultLabel2.getText() + "\nPlayer 2 lost Pair Plus");
				}
			} else{
				playerTwo.totalWinnings -= (playerTwo.anteBet + playerTwo.anteBet);
			}
		});
		p1Fold.setOnAction(e -> {
			p1PorF = 'F';
			p1Fold.setVisible(false);
			p1Play.setVisible(false);
			p2Play.setVisible(true);
			p2Fold.setVisible(true);

			resultLabel.setText("Player 1 Folded");
		});

		p2Fold.setOnAction(e -> {
			p2PorF = 'F';
			p2Fold.setVisible(false);
			p2Play.setVisible(false);
			String dealerHandString = formatHand(theDealer.dealersHand);
			dealerHandLabel.setText("Dealer hand: " + dealerHandString);
			Continue.setVisible(true);
			resultLabel.setVisible(true);
			resultLabel2.setVisible(true);
			resultLabel2.setText("Player 2 Folded");
			if (p1PorF == 'P'){
				int ppw1 = ThreeCardLogic.evalPPWinnings(playerOne.hand, playerOne.pairPlusBet);
				int wol = ThreeCardLogic.compareHands(theDealer.dealersHand, playerOne.hand);
				if (wol == 2){
					playerOne.totalWinnings -= (playerOne.anteBet + playerOne.pairPlusBet);
				} else if (wol == 1){
					playerOne.totalWinnings += (playerOne.anteBet + playerOne.anteBet);
				}
				playerOne.totalWinnings += ppw1;
				if (ppw1 > 0){
					resultLabel.setText(resultLabel.getText() + "\nPlayer 1 Won Pair Plus: " + ppw1);
				} else {
					resultLabel.setText(resultLabel.getText() + "\nPlayer 1 lost Pair Plus");
				}
			} else{
				playerOne.totalWinnings -= (playerTwo.anteBet + playerOne.pairPlusBet);
			}
			if (p2PorF == 'P') {
				int ppw2 = ThreeCardLogic.evalPPWinnings(playerTwo.hand, playerTwo.pairPlusBet);
				int wol = ThreeCardLogic.compareHands(theDealer.dealersHand, playerTwo.hand);
				if (wol == 2) {
					playerTwo.totalWinnings -= (playerTwo.anteBet + playerTwo.pairPlusBet);
				} else if (wol == 1) {
					playerTwo.totalWinnings += (playerTwo.anteBet + playerTwo.anteBet);
				}
				playerTwo.totalWinnings += ppw2;
				if (ppw2 > 0) {
					resultLabel2.setText(resultLabel2.getText() + "\nPlayer 2 Won Pair Plus: " + ppw2);
				} else {
					resultLabel2.setText(resultLabel2.getText() + "\nPlayer 2 lost Pair Plus");
				}
			} else{
				playerTwo.totalWinnings -= (playerTwo.anteBet + playerTwo.anteBet);
			}
		});
		buttonsBox.getChildren().add(Continue);
		//"resets" the game while updating all the necessary values
		Continue.setOnAction(e -> {
			if (player1won) {
				result1 = "won";
			} else if (player1won == false) {
				result1 = "lost";
			} else{
				result1 = " ";
			}
			if(player2won) {
				result2 = "won";
			} else if (player2won == false){
				result2 = "lost";
			} else{
				result2 = " ";
			}
			showGameplayScreen(primaryStage);
		});
		//setup for menu buttons and menu
		MenuBar menuBar = new MenuBar();
		Menu optionsMenu = new Menu("Options");

		MenuItem exitMenuItem = new MenuItem("Exit");
		MenuItem newLookMenuItem = new MenuItem("New Look");
		MenuItem resetMenuItem = new MenuItem("Fresh Start");
		resetMenuItem.setOnAction(e -> {
			playerOne = new Player();
			playerTwo = new Player();
			showGameplayScreen(primaryStage);
		});
		optionsMenu.getItems().addAll(exitMenuItem, resetMenuItem, newLookMenuItem);
		menuBar.getMenus().addAll(optionsMenu);
		gameplayScreen.setTop(menuBar);

		VBox centerBox = new VBox(40);
		centerBox.setAlignment(Pos.CENTER);
		centerBox.getChildren().addAll(resultBox, cardsBox, inputs, playersBox, betBox, winningsBox, buttonsBox, dealButton);


		gameplayScreen.setCenter(centerBox);

		Scene gamePlayScene = new Scene(gameplayScreen, 700, 700);
		//gameplayScreen.getStylesheets().add(getClass().getResource("/resources/background.css").toExternalForm());
		newLookMenuItem.setOnAction(e -> {
			Random rand = new Random();
			int r = rand.nextInt(40)+59;
			int g = rand.nextInt(40)+59;
			int b = rand.nextInt(40)+59;

			gameplayScreen.setStyle("-fx-background-color: #" + r + g + b + ";");
		});

		primaryStage.setScene(gamePlayScene);
		primaryStage.show();

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}

	//feel free to remove the starter code from this method
	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
		primaryStage.setTitle("Welcome to Three Card Poker");
		playerOne = new Player();
		playerTwo = new Player();
		theDealer = new Dealer();

		 Rectangle rect = new Rectangle (100, 40, 100, 100);
	     rect.setArcHeight(50);
	     rect.setArcWidth(50);
	     rect.setFill(Color.BLACK);

	     RotateTransition rt = new RotateTransition(Duration.millis(5000), rect);
	     rt.setByAngle(270);
	     rt.setCycleCount(4);
	     rt.setAutoReverse(true);
		 rect.setFill(Color.RED);
	     SequentialTransition seqTransition = new SequentialTransition (
	         new PauseTransition(Duration.millis(500)),
	         rt
	     );
	     seqTransition.play();
	     
	     FadeTransition ft = new FadeTransition(Duration.millis(5000), rect);
	     ft.setFromValue(1.0);
	     ft.setToValue(0.3);
	     ft.setCycleCount(4);
	     ft.setAutoReverse(true);

	     ft.play();
	     BorderPane root = new BorderPane();
	     root.setCenter(rect);

		 StackPane startBox = new StackPane();
		 Button Start = new Button("Start Game");
		 startBox.getChildren().addAll(rect, Start);
		 startBox.setAlignment(Pos.CENTER);
		 StackPane TitlePane = new StackPane();
		 Label TitleLabel = new Label("Three Card Poker Game");
		 TitleLabel.setTextFill(Color.WHITE);
		 TitleLabel.setFont(Font.font("Times New Roman", 50));
		 TitlePane.setAlignment(Pos.TOP_CENTER);
		 TitlePane.getChildren().addAll(TitleLabel);
		 Start.setOnAction(e -> showWelcomeScreen(primaryStage));
		 root.setCenter(startBox);
		 root.setTop(TitlePane);
	     Scene scene = new Scene(root, 700,700);
			primaryStage.setScene(scene);
			Start.setTextFill(Color.BLACK);
			Start.setStyle("-fx-background-color: transparent");
			root.setStyle("-fx-background-color: #000000;");

			primaryStage.show();




				
		
	}

}
