import java.util.ArrayList;

public class ThreeCardLogic {
    //evaluate the hand and depending return the correct value
    public static int evalHand(ArrayList<Card> hand) {
        hand.sort((c1, c2) -> c1.value - c2.value);

        boolean isFlush = hand.get(0).suit == hand.get(1).suit && hand.get(0).suit == hand.get(2).suit;
        boolean isStraight = hand.get(2).value == hand.get(1).value+1 && hand.get(1).value == hand.get(0).value+1;
        boolean isTOAK = hand.get(0).value == hand.get(1).value && hand.get(1).value == hand.get(2).value;
        boolean isPair = hand.get(0).value == hand.get(1).value || hand.get(0).value == hand.get(2).value || hand.get(1).value == hand.get(2).value;
        if (isFlush && isStraight){
            return 1;
        } else if(isTOAK){
            return 2;
        } else if(isStraight){
            return 3;
        } else if(isFlush){
            return 4;
        } else if(isPair){
            return 5;
        } else{
            return 0;
        }
    }
    //determine how much money won from pair plus
    public static int evalPPWinnings(ArrayList<Card> hand, int bet) {
        int handType = evalHand(hand);
        switch (handType) {
            case 1:
                return bet * 40;
            case 2:
                return bet * 30;
            case 3:
                return bet * 6;
            case 4:
                return bet * 3;
            case 5:
                return bet;
            default:
                return 0;
        }
    }
    //compare the values of 2 hands
    public static int compareHands(ArrayList<Card> Dealer, ArrayList<Card> Player) {
        int DealerValue = evalHand(Dealer);
        int PlayerValue = evalHand(Player);
        if (DealerValue == 0 && highestCard(Dealer) < 12){
            return 0;
        }
        if (DealerValue < PlayerValue) {
            return 1;
        } else if (DealerValue > PlayerValue) {
            return 2;
        } else if (DealerValue == PlayerValue) {
            return tieBreaker(Dealer, Player);
        }
        return 0;
    }
    //shows the value of the highest card in a hand
    public static int highestCard(ArrayList<Card> cards) {
        int highestCardValue = 0;
        for (Card card : cards) {
            if (card.value > highestCardValue){
                highestCardValue = card.value;
            }
        }
        return highestCardValue;
    }
    //if tie, aka both have same value, determine high card otherwise draw
    public static int tieBreaker(ArrayList<Card> Dealer, ArrayList<Card> Player) {
        int highestDealer = highestCard(Dealer);
        int highestPlayer = highestCard(Player);
        if (highestDealer == highestPlayer){
            return 0;
        } else if (highestDealer > highestPlayer){
            return 1;
        } else if (highestDealer < highestPlayer){
            return 2;
        }
        return 0;
    }
}
