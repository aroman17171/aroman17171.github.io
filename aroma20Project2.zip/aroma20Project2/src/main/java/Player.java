import java.util.ArrayList;

public class Player {
    public ArrayList<Card> hand;
    public int anteBet;
    public int playBet;
    public int pairPlusBet;
    public int totalWinnings;
    //creates a player with specific bets and money
    public Player(){
        hand = new ArrayList<>();
        anteBet = 0;
        playBet = 0;
        pairPlusBet = 0;
        totalWinnings = 100;
    }
}
