import java.util.ArrayList;

public class Dealer {
    public Deck theDeck;
    public ArrayList<Card> dealersHand;
    public Dealer() {
        theDeck = new Deck();
        dealersHand = new ArrayList<>();
    }
    //pushes out a new deck if it gets too low and creates a hand to give cards to
    public ArrayList<Card> dealHand() {
        if (theDeck.size() <= 34) {
            theDeck.newDeck();
        }
        ArrayList<Card> hand = new ArrayList<>();
        for (int i=0; i<3; i++){
            hand.add(theDeck.remove(0));
        }
        return hand;
    }
}
