import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class PokerInfoTests {

	private PokerInfo pokerInfo;

	@BeforeEach
	public void setUp() {
		pokerInfo = new PokerInfo();
	}

	@Test
	public void testSetAndGetAction() {
		pokerInfo.setAction("Bet");
		assertEquals("Bet", pokerInfo.getAction(), "The action should be 'Bet'.");
	}

	@Test
	public void testSetAndGetMessage() {
		pokerInfo.setMessage("You win!");
		assertEquals("You win!", pokerInfo.getMessage(), "The message should be 'You win!'.");
	}

	@Test
	public void testSetAndGetAnteBet() {
		pokerInfo.setAnteBet(10);
		assertEquals(10, pokerInfo.getAnteBet(), "The ante bet should be 10.");
	}

	@Test
	public void testSetAndGetPairPlusBet() {
		pokerInfo.setPairPlusBet(20);
		assertEquals(20, pokerInfo.getPairPlusBet(), "The pair plus bet should be 20.");
	}

	@Test
	public void testSetAndGetTotalWinnings() {
		pokerInfo.setTotalWinnings(150);
		assertEquals(150, pokerInfo.getTotalWinnings(), "The total winnings should be 150.");
	}

	@Test
	public void testSetAndGetWonOrLost() {
		pokerInfo.setWonOrLost(true);
		assertTrue(pokerInfo.getWonOrLost(), "The player should have won.");

		pokerInfo.setWonOrLost(false);
		assertFalse(pokerInfo.getWonOrLost(), "The player should have lost.");
	}
}
