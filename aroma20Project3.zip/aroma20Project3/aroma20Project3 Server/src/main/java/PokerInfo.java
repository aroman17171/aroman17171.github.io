import java.io.Serializable;

public class PokerInfo implements Serializable {
    //initialize with serial so no issues occur
    private static final long serialVersionUID = 1L;
    public String action = "";
    public String message = "";
    public int anteBet = 0;
    public int pairPlusBet = 0;
    public int totalWinnings = 100;
    public boolean WonOrLost = false;
    //setters and getters
    public void setAction(String action) {
        this.action = action;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public void setAnteBet(int anteBet) {
        this.anteBet = anteBet;
    }

    public void setPairPlusBet(int pairPlusBet) {
        this.pairPlusBet = pairPlusBet;
    }

    public void setTotalWinnings(int totalWinnings) {
        this.totalWinnings = totalWinnings;
    }

    public String getMessage() {
        return message;
    }

    public String getAction() {
        return action;
    }

    public int getAnteBet() {
        return anteBet;
    }

    public int getPairPlusBet() {
        return pairPlusBet;
    }

    public int getTotalWinnings(){
        return totalWinnings;
    }
    public void setWonOrLost(boolean WonOrLost) {
        this.WonOrLost = WonOrLost;
    }
    public boolean getWonOrLost() {
        return WonOrLost;
    }
}
