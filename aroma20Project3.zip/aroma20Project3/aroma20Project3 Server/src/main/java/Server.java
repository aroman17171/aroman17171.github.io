import javafx.application.Platform;
import javafx.scene.control.ListView;

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

public class Server {
    private ServerSocket serverSocket;
    private List<ClientHandler> clients = new CopyOnWriteArrayList<>();  // Thread-safe list
    private Deck deck = new Deck();
    private ListView<String> gameInfoList;
    private Map<ClientHandler, String> clientPlayerMap = new HashMap<>();


    public Server(ListView<String> gameInfoList) {
        this.gameInfoList = gameInfoList;
    }
    //updates the number of clients in the server
    private void updateClientCount() {
        int clientCount = clients.size(); // Get the current number of connected clients
        Platform.runLater(() -> {
            // Remove the old client count message (if any)
            gameInfoList.getItems().removeIf(item -> item.startsWith("Clients connected:"));
            // Add the new client count message
            gameInfoList.getItems().add("Clients connected: " + clientCount);
        });
    }

    public void startServer(int port) {
        try {
            serverSocket = new ServerSocket(port);
            updateGameInfo("Server started on port " + port);

            while (true) {
                Socket clientSocket = serverSocket.accept();
                updateGameInfo("New client connected: " + clientSocket.getInetAddress());

                ClientHandler clientHandler = new ClientHandler(clientSocket);
                synchronized (clients) {
                    clients.add(clientHandler);  // Thread-safe addition
                    clientPlayerMap.put(clientHandler, "Player " + clients.size());
                }
                updateGameInfo(clientPlayerMap.get(clientHandler) + " has joined the game.");
                updateClientCount();
                new Thread(clientHandler).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void stopServer() {
        try {
            for (ClientHandler client : clients) {
                client.close();
            }
            if (serverSocket != null) {
                serverSocket.close();
            }
            updateGameInfo("Server stopped.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private synchronized void updateGameInfo(String info) {
        Platform.runLater(() -> gameInfoList.getItems().add(info));
    }

    // Inner class to handle each client
    class ClientHandler implements Runnable {
        private Socket socket;
        private ObjectInputStream in;
        private ObjectOutputStream out;
        private PokerInfo pokerInfo;

        public ClientHandler(Socket socket) {
            this.socket = socket;
            try {
                this.in = new ObjectInputStream(socket.getInputStream());
                this.out = new ObjectOutputStream(socket.getOutputStream());
                pokerInfo = new PokerInfo();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void run() {
            try {
                while (true) {
                    Object input = in.readObject();
                    if (input == null) {
                        break;  // Stop reading if null
                    }
                    String playerLabel = clientPlayerMap.get(this);
                    if (input instanceof PokerInfo) {
                        PokerInfo clientPokerInfo = (PokerInfo) input;
                        // Handle the actions
                        switch (clientPokerInfo.getAction()) {
                            case "DEAL":
                                // Deal cards logic
                                clientPokerInfo.setMessage("Incorrect Bets!");
                                updateGameInfo(playerLabel + " started a new game.");
                                int totalBet = clientPokerInfo.getAnteBet() + clientPokerInfo.getPairPlusBet();
                                int totalWinnings = clientPokerInfo.getTotalWinnings();
                                break;

                            case "PLAY":
                                // Calculate the bet
                                totalBet = clientPokerInfo.getAnteBet() * 2 + clientPokerInfo.getPairPlusBet();
                                totalWinnings = clientPokerInfo.getTotalWinnings();
                                clientPokerInfo.setMessage("Bet received: $" + totalBet);
                                updateGameInfo(playerLabel + " bet: $" + totalBet);
                                break;

                            case "FOLD":
                                // Handle fold logic
                                totalBet = clientPokerInfo.getAnteBet() * 2 + clientPokerInfo.getPairPlusBet();
                                totalWinnings = clientPokerInfo.getTotalWinnings();
                                clientPokerInfo.setMessage("Player folded. Bet forfeited");
                                updateGameInfo(playerLabel + " folded. Lost bet: $" + totalBet);
                                break;

                            case "WON":
                                totalBet = clientPokerInfo.getAnteBet() * 2 + clientPokerInfo.getPairPlusBet(); // Ensure consistent bet calculation
                                totalWinnings = clientPokerInfo.getTotalWinnings();
                                clientPokerInfo.setMessage("Player won! Winnings: $" + totalBet);
                                updateGameInfo(playerLabel + " won: $" + totalBet);
                                break;
                            case "LOST":
                                totalBet = clientPokerInfo.getAnteBet() * 2 + clientPokerInfo.getPairPlusBet(); // Ensure consistent bet calculation
                                totalWinnings = clientPokerInfo.getTotalWinnings();
                                clientPokerInfo.setMessage("Player lost! Lost: $" + totalBet);
                                updateGameInfo(playerLabel + " lost: $" + totalBet);
                                break;
                            case "PAIRPLUS":
                                int ppw = clientPokerInfo.getPairPlusBet();
                                String temp = clientPokerInfo.getMessage();
                                totalWinnings = clientPokerInfo.getTotalWinnings();
                                clientPokerInfo.setMessage(temp + "\nPlayer won pair plus! Won: $" + ppw);
                                updateGameInfo(playerLabel + " won pair plus: $" + ppw);
                                updateGameInfo(playerLabel + " Total: $" + totalWinnings);
                                break;
                            case "TIE":
                                clientPokerInfo.setMessage("Tie!");
                                totalWinnings = clientPokerInfo.getTotalWinnings();
                                updateGameInfo(playerLabel + "Tie, Total: $" + totalWinnings);
                                break;
                            default:
                                clientPokerInfo.setMessage("Tie!");
                                totalWinnings = clientPokerInfo.getTotalWinnings();
                                updateGameInfo(playerLabel + "Tie, Total: $" + totalWinnings);
                                break;
                        }

                        // Update the server UI with the game info
                        updateGameInfo(playerLabel + " action: " + clientPokerInfo.getAction());
                        updateGameInfo(playerLabel + " Total: $" + clientPokerInfo.getTotalWinnings());


                        // Send the updated info back to the client
                        out.writeObject(clientPokerInfo);
                        out.flush();
                    }
                }
            } catch (EOFException e) {
                System.out.println("Client has closed the connection.");
            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            } finally {
                try {
                    // Make sure the client is removed and socket closed properly
                    clients.remove(this);
                    updateClientCount();
                    socket.close();
                    updateGameInfo("Client disconnected: " + socket.getInetAddress());
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        public void close() throws IOException {
            socket.close();
        }

    }
}
