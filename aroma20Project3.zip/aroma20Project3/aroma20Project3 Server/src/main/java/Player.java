import java.io.Serializable;
import java.util.ArrayList;

public class Player implements Serializable {
    public ArrayList<Card> hand;
    public int anteBet;
    public int playBet;
    public int pairPlusBet;
    public int totalWinnings;

    public Player(){
        hand = new ArrayList<>();
        anteBet = 0;
        playBet = 0;
        pairPlusBet = 0;
        totalWinnings = 100;
    }
}
