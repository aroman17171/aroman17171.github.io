import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class ServerGUI extends Application {
    private TextField portField;
    private Button startButton;
    private Button stopButton;
    private ListView<String> listView;
    private Server server;

    @Override
    public void start(Stage primaryStage) {
        //create all necessary components
        portField = new TextField("12345");
        startButton = new Button("Start Server");
        stopButton = new Button("Stop Server");
        stopButton.setDisable(true);
        listView = new ListView<>();



        VBox root = new VBox(10, new Label("Port:"), portField, startButton);
        Scene scene = new Scene(root, 200, 100);
        VBox root2 = new VBox(10, new Label("Server Started:"), stopButton, new Label("Game Stats:"), listView);
        Scene scene2 = new Scene(root2, 400, 400);
        root.setStyle("-fx-background-color: #fcc");
        root2.setStyle("-fx-background-color: #cfc");
        primaryStage.setTitle("3 Card Poker Server");
        primaryStage.setScene(scene);
        primaryStage.show();

        startButton.setOnAction(e -> {
            startServer();
            primaryStage.setScene(scene2);
            primaryStage.show();
        });
        stopButton.setOnAction(e -> {
            stopServer();
            primaryStage.setScene(scene);
            primaryStage.show();
        });
    }
    //starts the server with port
    private void startServer() {
        int port = Integer.parseInt(portField.getText());
        server = new Server(listView);
        new Thread(() -> server.startServer(port)).start();

        listView.getItems().add("Server started on port " + port);
        startButton.setDisable(true);
        stopButton.setDisable(false);
        //updateGameStats("Game started");
        updateClientCount(0);

    }
    //kills or stops the server
    private void stopServer() {
        server.stopServer();
        //listView.getItems().add("Server stopped.");
        startButton.setDisable(false);
        stopButton.setDisable(true);
    }

    // update the game stats when a result is obtained
    public void updateGameStats(String info) {
        listView.getItems().add(info);
    }

    //update the client count
    public void updateClientCount(int count) {
        listView.getItems().add("Clients connected: " + count);
    }

    public static void main(String[] args) {
        launch(args);
    }
}