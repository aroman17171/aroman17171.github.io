import java.io.Serializable;

public class Card implements Serializable {
    public char suit;
    public int value;
    //simple suit and value for a card
    public Card(char suit, int value) {
        this.suit = suit;
        this.value = value;
    }
}
