import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import javafx.geometry.Pos;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import java.util.ArrayList;
import java.util.Random;

public class ClientGUI extends Application {
    //Add sections for server access
    private TextField portField, ipField;
    private Button connectButton;
    private PokerClientLogic clientLogic;

    //Initialize all players
    public Player playerOne;
    public Dealer theDealer;

    //create screens
    private BorderPane welcomeScreen;
    private BorderPane gameplayScreen;
    //create labels for later use
    Label p1HandLabel;
    Label p1BetsLabel;
    Label dealerHandLabel;
    Label resultLabel;
    Label p1WinningsLabel;
    Label anteBetLabel1;
    Label playBetLabel1;
    Label pairPlusBetLabel1;

    Label infoLabel = new Label();
    //initialize some booleans for later use
    char player1won = 'x';

    boolean dealerWon = false;
    //Creates char variables for later use
    char p1PorF = 'x';

    //determines input from user and updates the bet once button pressed
    private void placeAnteBet(int i, int player) {
        if (player == 1) {
            playerOne.anteBet = i;
        }
        System.out.println("Ante bet placed by Player" + player + ": " + i);
    }

    //same as ante, except for pair plus bet, takes input from field after button press
    private void placePairPlusBet(int i, int player) {
        if (player == 1) {
            playerOne.pairPlusBet = i;
        }
        System.out.println("Pair bet placed by Player" + player + ": " + i);
    }

    //gives each player a hand and shows the players cards while keeping the dealer hidden
    //until either folded or played
    private void dealCards() {
        playerOne.hand = theDealer.dealHand();

        theDealer.dealersHand = theDealer.dealHand();

        System.out.println("Player hand: " + playerOne.hand);
        String p1HandString = formatHand(playerOne.hand);
        p1HandLabel.setText("Player hand: " + p1HandString);
        dealerHandLabel.setText("Dealer hand: ?? ?? ??");
        int playerOneScore = ThreeCardLogic.evalHand(playerOne.hand);
        System.out.println("Player score: " + playerOneScore);

        //determines if win or lose
        int winner1 = ThreeCardLogic.compareHands(theDealer.dealersHand, playerOne.hand);

        String resultMessage = "Error";


        if (winner1 == 1) {
            player1won = 't';
            resultMessage = "Player wins!";

        } else if (winner1 == 2) {
            dealerWon = true;
            resultMessage = "Dealer wins!";
        } else {
            resultMessage = "No one wins!";
        }
        resultLabel.setText(resultMessage);

        System.out.println(resultMessage);

    }

    //formats the cards to a more readable style
    private String formatHand(ArrayList<Card> hand) {
        StringBuilder sb = new StringBuilder();
        for (Card card : hand) {
            String value = String.valueOf(card.value);
            if (card.value > 10) {
                if (card.value == 11) {
                    value = "J";
                } else if (card.value == 12) {
                    value = "Q";
                } else if (card.value == 13) {
                    value = "K";
                } else if (card.value == 14) {
                    value = "A";
                }
            }
            sb.append("[").append(value).append(" of ").append(card.suit).append("]").append(" ");
        }
        return sb.toString();
    }

    //once button pressed show the welcome screen and show play or exit button
    private void showWelcomeScreen(Stage primaryStage) {
        welcomeScreen = new BorderPane();
        welcomeScreen.setStyle("-fx-background-color: #354535");
        Label welcomeLabel = new Label("Welcome to Three Card Poker!");
        welcomeLabel.setFont(Font.font("Times New Roman", 50));
        welcomeLabel.setTextFill(Color.BLACK);
        Button playButton = new Button("Play");
        Button exitButton = new Button("Exit");

        playButton.setOnAction(e -> showGameplayScreen(primaryStage));
        exitButton.setOnAction(e -> System.exit(0));

        VBox vbox = new VBox(20, welcomeLabel, playButton, exitButton);
        vbox.setAlignment(Pos.CENTER);
        welcomeScreen.setCenter(vbox);

        Scene welcomeScene = new Scene(welcomeScreen, 700, 700);
        primaryStage.setScene(welcomeScene);
        primaryStage.show();
    }

    public String result1 = " ";

    //shows the gameplay screen, allows players to make bets as well as proceed through the game
    private void showGameplayScreen(Stage primaryStage) {

        gameplayScreen = new BorderPane();
        gameplayScreen.setStyle("-fx-background-color: #F0FFF9");
        infoLabel.setText("");

        p1HandLabel = new Label("Player hand: ");

        dealerHandLabel = new Label("Dealer hand: ");
        HBox cardsBox = new HBox(20, p1HandLabel, dealerHandLabel);
        cardsBox.setAlignment(Pos.CENTER);
        Label p1Label = new Label("Player: ");

        HBox playersBox = new HBox(300, p1Label);
        playersBox.setAlignment(Pos.CENTER);
        anteBetLabel1 = new Label("Ante bet: ");
        playBetLabel1 = new Label("Play bet: ");
        pairPlusBetLabel1 = new Label("Pair Plus bet: ");

        Label anteFieldLabel = new Label("Ante bet (5-25):");
        TextField anteBetField = new TextField();
        Label pairPlusFieldLabel = new Label("Pair Plus bet (5-25):");
        TextField pairPlusBetField = new TextField();


        HBox inputs = new HBox(5, anteFieldLabel, anteBetField, pairPlusFieldLabel, pairPlusBetField);
        HBox betBox = new HBox(5, anteBetLabel1, playBetLabel1, pairPlusBetLabel1);
        inputs.setAlignment(Pos.CENTER);
        betBox.setAlignment(Pos.CENTER);
        resultLabel = new Label("Result Player: " + result1);
        VBox resultBox = new VBox(5, infoLabel, resultLabel);
        resultBox.setAlignment(Pos.TOP_CENTER);
        p1WinningsLabel = new Label("Player winnings: " + playerOne.totalWinnings);
        p1BetsLabel = new Label("Player bets: 0");

        VBox winningsBox = new VBox(10, p1WinningsLabel);
        winningsBox.setAlignment(Pos.CENTER);
        Button p1Bets = new Button("Player bets ");
        winningsBox.getChildren().addAll(p1Bets);
        Button dealButton = new Button("Deal cards");
        //Setups for button presses to have each button set bets for each player
        p1Bets.setOnAction(e -> {
            playerOne.anteBet = Integer.parseInt(anteBetField.getText());
            playerOne.pairPlusBet = Integer.parseInt(pairPlusBetField.getText());
            if (playerOne.anteBet >= 5 && playerOne.anteBet <= 25 && playerOne.pairPlusBet >= 5 && playerOne.pairPlusBet <= 25) {
                placeAnteBet(playerOne.anteBet, 1);
                placePairPlusBet(playerOne.pairPlusBet, 1);
                anteBetLabel1.setText("Ante bet: " + String.valueOf(playerOne.anteBet));
                playBetLabel1.setText("Play bet: " + String.valueOf(playerOne.anteBet));
                pairPlusBetLabel1.setText("Pair bet: " + String.valueOf(playerOne.pairPlusBet));

                p1BetsLabel.setText("Player bets: " + (playerOne.anteBet + playerOne.playBet + playerOne.pairPlusBet));
            }
        });

        //setup for play or fold per player
        Button p1Play = new Button("Player play");
        Button p1Fold = new Button("Player fold");
        p1Play.setVisible(false);
        p1Fold.setVisible(false);
        playBetLabel1.setVisible(false);
        HBox buttonsBox = new HBox(10);
        buttonsBox.setAlignment(Pos.BOTTOM_CENTER);
        buttonsBox.getChildren().addAll(p1Play, p1Fold);
        //once pressed will deal and lock in all bets, if bets aren't ready will not proceed
        dealButton.setOnAction(e -> {
            sendDeal();
            int p1Ante = playerOne.anteBet;
            int p1Pair = playerOne.pairPlusBet;
            //determines if each bet is correct value range
            if (((p1Ante >= 5 && p1Ante <= 25) && (p1Pair >= 5 && p1Pair <= 25))) {
                dealCards();
                anteBetLabel1.setText("Ante bet: " + String.valueOf(playerOne.anteBet));
                playBetLabel1.setText("Play bet: " + String.valueOf(playerOne.anteBet));
                pairPlusBetLabel1.setText("Pair bet: " + String.valueOf(playerOne.pairPlusBet));
                //shows all visible buttons and hides if necessary
                p1Play.setVisible(true);
                p1Fold.setVisible(true);
                dealButton.setVisible(false);
                p1Bets.setVisible(false);
                anteBetField.setVisible(false);
                pairPlusBetField.setVisible(false);
                resultLabel.setVisible(false);

                anteFieldLabel.setVisible(false);
                pairPlusFieldLabel.setVisible(false);

            }
        });
        //Setup for play and fold buttons
        Button Continue = new Button("Continue");
        Continue.setVisible(false);
        //if player presses paly
        p1Play.setOnAction(e -> {
            sendBet();
            p1PorF = 'P';
            p1BetsLabel.setText("Player bets: " + (playerOne.anteBet + playerOne.anteBet + playerOne.pairPlusBet));
            p1Play.setVisible(false);
            p1Fold.setVisible(false);
            playBetLabel1.setVisible(true);

                int ppw1 = ThreeCardLogic.evalPPWinnings(playerOne.hand, playerOne.pairPlusBet);
                int wol = ThreeCardLogic.compareHands(theDealer.dealersHand, playerOne.hand);
                if (wol == 2) {
                    playerOne.totalWinnings -= (playerOne.anteBet*2 + playerOne.pairPlusBet);
                    sendLost();
                } else if (wol == 1) {
                    playerOne.totalWinnings += (playerOne.anteBet + playerOne.anteBet);
                    sendWon();
                } else{
                    player1won = 'x';
                    sendTie();
                }
                playerOne.totalWinnings += ppw1;
                if (ppw1 > 0) {
                    resultLabel.setText(resultLabel.getText() + "\nPlayer Won Pair Plus: " + ppw1);
                    sendPairPlus();
                } else {
                    resultLabel.setText(resultLabel.getText() + "\nPlayer lost Pair Plus");
                }

            String dealerHandString = formatHand(theDealer.dealersHand);
            dealerHandLabel.setText("Dealer hand: " + dealerHandString);
            Continue.setVisible(true);
            resultLabel.setVisible(true);
        });

        //if player presses fold
        p1Fold.setOnAction(e -> {
            p1PorF = 'F';
            p1Fold.setVisible(false);
            p1Play.setVisible(false);
            resultLabel.setText("Player Folded");
            player1won = 'f';
            playerOne.totalWinnings -= (playerOne.anteBet + playerOne.pairPlusBet);
            String dealerHandString = formatHand(theDealer.dealersHand);
            dealerHandLabel.setText("Dealer hand: " + dealerHandString);
            Continue.setVisible(true);
            resultLabel.setVisible(true);
            sendFold();
        });

        buttonsBox.getChildren().add(Continue);
        //"resets" the game while updating all the necessary values
        Continue.setOnAction(e -> {
            if (player1won=='t') {
                result1 = "won";

            } else if (player1won == 'f') {
                result1 = "lost";

            } else {
                result1 = "Tie";
            }
            showGameplayScreen(primaryStage);
        });
        //setup for menu buttons and menu
        MenuBar menuBar = new MenuBar();
        Menu optionsMenu = new Menu("Options");

        MenuItem exitMenuItem = new MenuItem("Exit");
        MenuItem newLookMenuItem = new MenuItem("New Look");
        MenuItem resetMenuItem = new MenuItem("Fresh Start");
        resetMenuItem.setOnAction(e -> {
            playerOne = new Player();
            showGameplayScreen(primaryStage);
        });
        optionsMenu.getItems().addAll(exitMenuItem, resetMenuItem, newLookMenuItem);
        menuBar.getMenus().addAll(optionsMenu);
        gameplayScreen.setTop(menuBar);

        VBox centerBox = new VBox(40);
        centerBox.setAlignment(Pos.CENTER);
        centerBox.getChildren().addAll(resultBox, cardsBox, inputs, playersBox, betBox, winningsBox, buttonsBox, dealButton);


        gameplayScreen.setCenter(centerBox);

        Scene gamePlayScene = new Scene(gameplayScreen, 700, 700);
        //gameplayScreen.getStylesheets().add(getClass().getResource("/resources/background.css").toExternalForm());
        newLookMenuItem.setOnAction(e -> {
            Random rand = new Random();
            int r = rand.nextInt(40) + 59;
            int g = rand.nextInt(40) + 59;
            int b = rand.nextInt(40) + 59;

            gameplayScreen.setStyle("-fx-background-color: #" + r + g + b + ";");
        });

        primaryStage.setScene(gamePlayScene);
        primaryStage.show();

    }

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        launch(args);
    }

    //feel free to remove the starter code from this method
    @Override
    public void start(Stage primaryStage) throws Exception {
        // TODO Auto-generated method stub
        primaryStage.setTitle("Welcome to Three Card Poker");
        playerOne = new Player();
        theDealer = new Dealer();
        showGameplayScreen(primaryStage);

        //Create client able to connect to server

        VBox welcomeLayout = new VBox(10);
        ipField = new TextField("127.0.0.1");
        portField = new TextField("12345");
        connectButton = new Button("Connect");
        connectButton.setOnAction(e -> {
            connectToServer(primaryStage);
            if (gameplayScreen != null) {
                primaryStage.setScene(gameplayScreen.getScene());
                //connectToServer(primaryStage);
            } else{
                System.out.println("gameplayScreen is not initialized");
                System.exit(0);
            }

        });
        //create start screen
        welcomeLayout.getChildren().addAll(new Label("IP:"), ipField, new Label("Port:"), portField, connectButton);
        Scene welcomeScene = new Scene(welcomeLayout, 300, 200);
        primaryStage.show();
        // Start with Welcome Scene
        primaryStage.setTitle("Three Card Poker Client");
        primaryStage.setScene(welcomeScene);
        primaryStage.show();


    }

    private void connectToServer(Stage primaryStage) {
        try {
            int port = Integer.parseInt(portField.getText());
            String ip = ipField.getText();
            clientLogic = new PokerClientLogic(port, ip, this);
            clientLogic.connect();
            primaryStage.setScene(gameplayScreen.getScene());
        } catch (Exception e) {
            showError("Failed to connect to server.");
            primaryStage.setScene(welcomeScreen.getScene());
            connectButton.setDisable(false);
            primaryStage.show();
        }
    }
    //All functions related to sending to the server
    private void sendDeal() {
        try {
            // Get the bet info from text fields
            PokerInfo betInfo = new PokerInfo();
            betInfo.setAction("DEAL");
            betInfo.setAnteBet(playerOne.anteBet);
            betInfo.setPairPlusBet(playerOne.pairPlusBet);
            betInfo.setTotalWinnings(playerOne.totalWinnings);
            // Send bet info to the server
            clientLogic.sendRequest(betInfo);
        } catch (Exception e) {
            showError("Error sending bets");
        }
    }


    public void showError(String message) {
        Platform.runLater(() -> {
            Alert alert = new Alert(Alert.AlertType.ERROR, message, ButtonType.OK);
            alert.showAndWait();
        });
    }

    private void sendBet() {
        PokerInfo request = new PokerInfo();
        request.setAction("PLAY");
        request.setAnteBet(playerOne.anteBet);
        request.setPairPlusBet(playerOne.pairPlusBet);
        request.setTotalWinnings(playerOne.totalWinnings);
        clientLogic.sendRequest(request);
    }

    private void sendFold() {
        PokerInfo request = new PokerInfo();
        request.setAction("FOLD");
        request.setTotalWinnings(playerOne.totalWinnings);
        clientLogic.sendRequest(request);
    }

    private void sendWon() {
        PokerInfo request = new PokerInfo();
        request.setAction("WON");
        request.setAnteBet(playerOne.anteBet);
        request.setPairPlusBet(playerOne.pairPlusBet);
        request.setTotalWinnings(playerOne.totalWinnings);
        clientLogic.sendRequest(request);
    }
    private void sendLost() {
        PokerInfo request = new PokerInfo();
        request.setAction("LOST");
        request.setAnteBet(playerOne.anteBet);
        request.setPairPlusBet(playerOne.pairPlusBet);
        request.setTotalWinnings(playerOne.totalWinnings);

        clientLogic.sendRequest(request);
    }
    private void sendPairPlus() {
        PokerInfo request = new PokerInfo();
        request.setAction("PAIRPLUS");
        request.setPairPlusBet(playerOne.pairPlusBet);
        request.setTotalWinnings(playerOne.totalWinnings);
        clientLogic.sendRequest(request);
    }
    private void sendTie() {
        PokerInfo request = new PokerInfo();
        request.setAction("TIE");
        request.setAnteBet(playerOne.anteBet);
        request.setPairPlusBet(playerOne.pairPlusBet);
        request.setTotalWinnings(playerOne.totalWinnings);
        clientLogic.sendRequest(request);
    }
    //display results on the client screen
    public void displayResults(PokerInfo results) {
        Platform.runLater(()-> {
            resultLabel.setText(results.message);
        });

    }


}