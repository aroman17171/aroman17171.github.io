import javafx.application.Platform;

import java.io.*;
import java.net.Socket;

public class PokerClientLogic implements Serializable {
    private Socket socket;
    private ObjectOutputStream outputStream;
    private ObjectInputStream inputStream;
    private ClientGUI gui;
    //logic behind sending and receiving from server
    public PokerClientLogic(int port, String ip, ClientGUI gui) {
        try {
            this.socket = new Socket(ip, port);
            this.outputStream = new ObjectOutputStream(socket.getOutputStream());
            this.inputStream = new ObjectInputStream(socket.getInputStream());
            this.gui = gui;
        } catch (IOException e) {
            throw new RuntimeException("Failed to connect to server.", e);
        }
    }
    //tries to connect to the server
    public void connect() {
        new Thread(() -> {
            try {
                while (!socket.isClosed()) {
                    PokerInfo response = receiveResponse();
                    if (response != null) {
                        gui.displayResults(response);
                    }
                }
            } catch (IOException | ClassNotFoundException e) {
                gui.showError("Disconnected from server.");
                e.printStackTrace();
            }
        }).start();
    }
    //send something from client to server
    public void sendRequest(PokerInfo request) {
        try {
            outputStream.writeObject(request);
            outputStream.flush();
        } catch (IOException e) {
            gui.showError("Failed to send request.\nServer most likely closed the connection.");
            e.printStackTrace();
            Platform.exit();
        }
    }
    //determines if response and reads in
    public PokerInfo receiveResponse() throws IOException, ClassNotFoundException {
        try {
            return (PokerInfo) inputStream.readObject();
        } catch (EOFException e) {
            System.out.println("End of stream reached, server might have closed the connection.");
            Platform.exit();
            return null;  // Handle EOF exception if necessary
        }
    }
}
