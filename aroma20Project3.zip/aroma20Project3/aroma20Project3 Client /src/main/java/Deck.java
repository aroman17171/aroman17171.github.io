import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;

public class Deck extends ArrayList<Card> implements Serializable {

    public Deck() {
        newDeck();
    }
    //creates a deck of 52 cards with a card for each number in a suit
    public void newDeck() {
        this.clear();
        char[] suits = {'H', 'S', 'D', 'C'};
        for (char suit : suits) {
            for (int i = 2; i <= 14; i++) {
                this.add(new Card(suit, i));
            }
        }
        Collections.shuffle(this);
    }
}